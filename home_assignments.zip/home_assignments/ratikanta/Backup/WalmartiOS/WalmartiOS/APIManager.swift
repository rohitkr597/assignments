//
//  APIManager.swift
//  WalmartiOS
//
//  Created by Rohit Kumar on 28/10/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import UIKit

class APIManager: NSObject {
    static var sharedManager = APIManager()
    private override init() {}
    
    func authenticateUser(userName:String, password:String, callback:((NSData?, NSURLResponse?, NSError?) -> ())?)  {
        if let url = URLBuilder.buildURL(Constants.LOGIN_PATH, queryParams: [Constants.kEmail:userName, Constants.kPassword: password]) {
            NetworkManager.peformRequest(RequestType.GET, url: url, params: nil, callback: { (data, response, error) in
                dispatch_async(dispatch_get_main_queue(), { 
                    if let d = data {
                        let str = String.init(data: d, encoding: NSUTF8StringEncoding)
                        print("resp:\(str)")
                    }
                    callback?(data,response,error)
                })
                
            })

        }
    }
    
    func fetchPrescriptions(cusId:Int, callback:((NSData?, NSURLResponse?, NSError?) -> ())? )  {
        let pescriptionPath = Constants.PRESCRIPTION_PATH + "/" + "\(cusId)"
        
        if let url = URLBuilder.buildURL(pescriptionPath, queryParams: nil) {
            NetworkManager.peformRequest(RequestType.GET, url: url, params: nil, callback: { (data, response, error) in
                dispatch_async(dispatch_get_main_queue(), {
                    if let d = data {
                        let str = String.init(data: d, encoding: NSUTF8StringEncoding)
                        print("resp:\(str)")
                    }
                    callback?(data,response,error)
                })
                
            })
            
        }
    }
    
    func refill(cusId:Int, drugs:[String], callback:((NSData?, NSURLResponse?, NSError?) -> ())?)  {
        let refillPath = Constants.REFILL_PATH + "/" +  "\(cusId)"
        let str = drugs.joinWithSeparator(",")
        if let url = URLBuilder.buildURL(refillPath, queryParams: [Constants.kRxNumber : str]) {
            NetworkManager.peformRequest(RequestType.GET, url: url, params: nil, callback: { (data, response, error) in
                dispatch_async(dispatch_get_main_queue(), {
                    if let d = data {
                        let str = String.init(data: d, encoding: NSUTF8StringEncoding)
                        print("resp:\(str)")
                    }
                    callback?(data,response,error)
                })
                
            })
            
        }

    }
}
