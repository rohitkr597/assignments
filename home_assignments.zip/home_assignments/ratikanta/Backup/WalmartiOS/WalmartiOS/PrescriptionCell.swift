//
//  PrescriptionCell.swift
//  WalmartiOS
//
//  Created by Rohit Kumar on 28/10/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import UIKit

class PrescriptionCell: UITableViewCell {
    @IBOutlet var nameLabel:UILabel!
    @IBOutlet var prescriberLabel:UILabel!
    @IBOutlet var priceLabel:UILabel!
    
    var prescription:Prescription? {
        didSet{
            self.nameLabel.text = prescription?.drugName
            self.prescriberLabel.text = prescription?.prescriber
            self.priceLabel.text = ""
            if let price = prescription?.price {
                self.priceLabel.text = "\(price)"
            }
        }
    }
}
