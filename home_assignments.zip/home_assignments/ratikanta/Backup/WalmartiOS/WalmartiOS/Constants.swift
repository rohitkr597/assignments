//
//  Constants.swift
//  WalmartiOS
//
//  Created by Rohit Kumar on 28/10/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import Foundation
class Constants {
    static let HOST_NAME = "http://172.28.124.74:8081"
    
    static let LOGIN_PATH = "customers/authenticate"
    static let PRESCRIPTION_PATH = "prescriptions"
    static let REFILL_PATH = "refill"


    
    static let kEmail = "emailId"
    static let kPassword = "pwd"
    static let kStatus = "status"
    static let kSuccess = "OK"
    static let kCustomerId = "customerId"
    static let kRxNumber = "rxNumber"

}