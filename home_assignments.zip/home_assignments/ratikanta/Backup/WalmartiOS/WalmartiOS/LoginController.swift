//
//  LoginController.swift
//  WalmartiOS
//
//  Created by Rohit Kumar on 27/10/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import UIKit

class LoginController: UIViewController {
    @IBOutlet var userNameField:UITextField!
    @IBOutlet var passwordField:UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func loginButtonTapped(sender:UIButton){
        APIManager.sharedManager.authenticateUser(userNameField.text!, password: passwordField.text!) { [unowned weakSelf = self] (data, response, error) in
            if let er = error {
                AppHelper.showAlert("Error!", message: er.localizedDescription, controller: weakSelf)
            }else {
                if let loginData = data {
                    let userInfo = DataParser.parseDataForLogin(loginData)
                    if userInfo.customerId > 0 {
                        AppHelper.saveCurrentCustomerId(userInfo.customerId)
                    }
                    weakSelf.launchPrescriptionScreen()
                }
            }
        }
    }
    
    func launchPrescriptionScreen()  {
        if let pVC = self.storyboard?.instantiateViewControllerWithIdentifier("PrescriptionController")  {
            self.navigationController?.pushViewController(pVC, animated: true)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
