//
//  URLBuilder.swift
//  WalmartiOS
//
//  Created by Rohit Kumar on 28/10/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import Foundation

class URLBuilder: NSObject {
    static func buildURL(path:String, queryParams:[String:String]?) -> NSURL? {
        var urlString = Constants.HOST_NAME + "/" + path
        if let query = queryParams {
            var querySring = ""
            for (key, val) in query {
                querySring += "\(key)=\(val)&"
            }
            querySring = querySring.substringToIndex(querySring.endIndex.advancedBy(-1))
            querySring = "?\(querySring)"
            urlString += querySring
        }
        return NSURL(string: urlString)
        
    }
}