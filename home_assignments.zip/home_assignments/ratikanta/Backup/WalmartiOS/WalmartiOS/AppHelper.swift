//
//  AppHelper.swift
//  WalmartiOS
//
//  Created by Rohit Kumar on 28/10/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import Foundation
import UIKit
class AppHelper: NSObject {
   static func saveCurrentCustomerId(cusId:Int)  {
        NSUserDefaults.standardUserDefaults().setInteger(cusId, forKey: Constants.kCustomerId)
    }
   static func getCurrentCustomerId() -> Int? {
        return NSUserDefaults.standardUserDefaults().integerForKey(Constants.kCustomerId)
    }
   static func showAlert(title:String?, message:String?, controller:UIViewController)  {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        let ok = UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil)
        alert.addAction(ok)
        controller.presentViewController(alert, animated: true, completion: nil)
    }
}