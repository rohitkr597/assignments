//
//  NetworkManager.swift
//  WalmartiOS
//
//  Created by Rohit Kumar on 27/10/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import UIKit
enum RequestType: String {
    case GET = "GET"
    case POST = "POST"
}

class NetworkManager: NSObject {
   class func peformRequest(type: RequestType, url: NSURL, params:[String:AnyObject]?, callback:((NSData?, NSURLResponse?, NSError?) -> ())?)  {
       // let url = NSURL(string: "https://itunes.apple.com/search?term=\(searchTerm)&media=software")
        let request = NSMutableURLRequest(URL: url)
        request.HTTPMethod = type.rawValue
        let config = NSURLSessionConfiguration.defaultSessionConfiguration()
        let session = NSURLSession(configuration: config)
        
        let task = session.dataTaskWithRequest(request, completionHandler: {(data, response, error) in
            
            callback?(data,response,error)
            // notice that I can omit the types of data, response and error
            
            // your code
            
        });
        
        // do whatever you need with the task e.g. run
        task.resume()
    }
}
