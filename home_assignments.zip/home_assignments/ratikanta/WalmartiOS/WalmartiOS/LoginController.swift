//
//  LoginController.swift
//  WalmartiOS
//
//  Created by Rohit Kumar on 27/10/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import UIKit

class LoginController: UIViewController {
    @IBOutlet var userNameField:UITextField!
    @IBOutlet var passwordField:UITextField!
    @IBOutlet var loginView:UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let cusId = AppHelper.getCurrentCustomerId() where  cusId > 0{
            self.view.makeToastActivity(.Center)
            launchPrescriptionScreen()
            self.view.hideToastActivity()
        }else {
            self.loginView.hidden = false
        }

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        if let cusId = AppHelper.getCurrentCustomerId() where  cusId > 0{
            self.loginView.hidden = true
        }else {
            self.loginView.hidden = false
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func loginButtonTapped(sender:UIButton){
        if let errror = validate() {
            AppHelper.showAlert("Oops!", message: errror, controller: self)
            return
        }
        self.view.makeToastActivity(.Center)
        APIManager.sharedManager.authenticateUser(userNameField.text!, password: passwordField.text!) { [unowned weakSelf = self] (data, response, error) in
            self.view.hideToastActivity()
            if let er = error {
                AppHelper.showAlert("Error!", message: er.localizedDescription, controller: weakSelf)
            }else {
                if let loginData = data {
                    let userInfo = DataParser.parseDataForLogin(loginData)
                    
                    if userInfo.customerId > 0 {
                        AppHelper.saveCurrentCustomerId(userInfo.customerId)
                    }
                    if userInfo.success {
                        weakSelf.launchPrescriptionScreen()
                    }else {
                        AppHelper.showAlert("Error!", message: "Wrong emailId or password", controller: weakSelf)
                    }
                   
                }
            }
        }
    }
    
    func launchPrescriptionScreen()  {
        if let pVC = self.storyboard?.instantiateViewControllerWithIdentifier("PrescriptionController")  {
            self.userNameField.text = ""
            self.passwordField.text = ""
            self.view.endEditing(true)
            pVC.navigationItem.hidesBackButton = true
            self.navigationController?.pushViewController(pVC, animated: true)
        }
    }
    
    func validate() -> String? {
        if userNameField.text?.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()).characters.count == 0 {
            return "user name cannot be blank"
        }
        if passwordField.text?.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceCharacterSet()).characters.count == 0 {
            return "password  cannot be blank"
        }
        if let email = userNameField.text  {
            if !AppHelper.isValidEmail(email) {
                return "Please enter valid email"
            }
        }
        
        return nil
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
