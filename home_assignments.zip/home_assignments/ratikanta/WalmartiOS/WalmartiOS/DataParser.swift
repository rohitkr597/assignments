//
//  DataParser.swift
//  WalmartiOS
//
//  Created by Rohit Kumar on 28/10/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import Foundation
class DataParser: NSObject {
    static func parseDataForLogin(data:NSData) -> (success:Bool, customerId:Int) {
        do {
            var success = false
            var cusID = 0
            let json = try NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.AllowFragments)
            if let status = json[Constants.kStatus] as? String {
                if status.caseInsensitiveCompare(Constants.kSuccess) == .OrderedSame{
                    success = true
                }
                if let id = json[Constants.kCustomerId] as? Int {
                    cusID = id
                }
            }
            return (success,cusID)
        }
        catch {
            return (false, 0)
        }
    }
   static func parsePrescriptionData(data:NSData) -> (success:Bool, prescriptions:[Prescription]?) {
        do {
            var success = false
            var prescriptions = [Prescription]()
            let json = try NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.AllowFragments)
            if let status = json[Constants.kStatus] as? String {
                if status.caseInsensitiveCompare(Constants.kSuccess) == .OrderedSame{
                    success = true
                    if let array = json["prescriptions"] as? [AnyObject] {
                        for item in array {
                            if let aPres = item as? [String:AnyObject] {
                                let presObj = Prescription()
                                presObj.price = aPres["price"] as? Int
                                presObj.remainingRefill = aPres["noOfRemainingRefill"] as? Int
                                presObj.prescriber = aPres["prescriberName"] as? String
                                presObj.expiryDate = aPres["expirationDate"] as? Int64
                                presObj.drugName = aPres["drugName"] as? String
                                presObj.lastRefillDate = aPres["lastRefillDate"] as? Int64
                                presObj.rxNumber = aPres["RxNumber"] as? String
                                prescriptions.append(presObj)
                                print("aPres:\(aPres)")
                            }
                        }
                    }
                }
                
            }
            return (success,prescriptions)
        }
        catch {
            return (false, nil)
        }

    }
    static func parseRefillData(data:NSData) -> (success:Bool, description:String?) {
        do {
            var success = false
            var description:String?
            let json = try NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.AllowFragments)
            if let status = json[Constants.kStatus] as? String {
                if status.caseInsensitiveCompare(Constants.kSuccess) == .OrderedSame{
                    success = true
                    
                }
                description = json["description"] as? String
                
            }
            return (success,description)
        }
        catch {
            return (false, nil)
        }

        
    }
}