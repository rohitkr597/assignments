//
//  PrescriptionController.swift
//  WalmartiOS
//
//  Created by Rohit Kumar on 28/10/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import Foundation
import UIKit

class PrescriptionController: UIViewController {
    private var dataSource = [Prescription]()
    private var refillIndexes = [String]()
    private var refillButton:UIBarButtonItem?
    private var refillMode = false
   @IBOutlet  private var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Your Prescriptions"
        self.navigationItem.hidesBackButton = true
        self.navigationItem.backBarButtonItem = nil
        let logOutButton = UIBarButtonItem(title: "Logout", style: .Plain, target: self, action: #selector(didTapLogout(_:)))
        self.navigationItem.leftBarButtonItem = logOutButton
        
        refillButton = UIBarButtonItem(title: "Refill", style: .Plain, target: self, action: #selector(didTapRefill(_:)))
        self.navigationItem.rightBarButtonItem = refillButton
        edgesForExtendedLayout = .None
        fetchPrescriptionData()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationItem.hidesBackButton = true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func didTapRefill(sender:UIBarButtonItem?) {
        if refillIndexes.count > 0 {
            sender?.title = "Refill"
            sendRefillRequest()
            
        }else {
           // sender?.title = "Cancel"
            refillMode = true
            self.view.makeToast("Now select a row by tapping it. Tap done to refill", duration: 2.0, position: .Top)
        }
    }
    func didTapLogout(sender:UIBarButtonItem?)   {
        AppHelper.clearCustomerId()
        self.navigationController?.popViewControllerAnimated(true)
    }
    func fetchPrescriptionData()  {
        self.view.makeToastActivity(.Center)
        if let cusId = AppHelper.getCurrentCustomerId() where cusId > 0  {
            APIManager.sharedManager.fetchPrescriptions(cusId, callback: {[unowned weakSelf = self] (data, response, error) in
                self.view.hideToastActivity()
                if let er = error {
                    AppHelper.showAlert("Error!", message: er.localizedDescription, controller: weakSelf)
                    
                }else {
                    if let presData = data {
                        let parsedData = DataParser.parsePrescriptionData(presData)
                        weakSelf.dataSource = parsedData.prescriptions ?? [Prescription]()
                        weakSelf.tableView.reloadData()
                }
                }
                }
            )

        }
    }
    func sendRefillRequest()  {
        self.view.makeToastActivity(.Center)
        if let cusId = AppHelper.getCurrentCustomerId() where cusId > 0  {
            var rxNumbers = [String]()
            for item in refillIndexes {
                if let index = Int(item) {
                     let obj = dataSource[index]
                    if let rx = obj.rxNumber {
                        rxNumbers.append("\(rx)")
                    }
                }
               
            }
            APIManager.sharedManager.refill(cusId, drugs: rxNumbers, callback: { [unowned weakSelf = self] (data, response, error) in
                self.view.hideToastActivity()
                if let er = error  {
                    AppHelper.showAlert("Error!", message: er.localizedDescription, controller: weakSelf)
                }else {
                    weakSelf.refillIndexes.removeAll()
                    if let d = data {
                        let responseData = DataParser.parseRefillData(d)
                        if responseData.success {
                            AppHelper.showAlert("Success", message: responseData.description, controller: weakSelf)
                        }else {
                            AppHelper.showAlert("Failure", message: responseData.description, controller: weakSelf)
                        }
                    }
                    weakSelf.tableView.reloadData()
                }
            })

        }
    }
}
extension PrescriptionController:UITableViewDataSource, UITableViewDelegate {
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCellWithIdentifier("PrescriptionCell") as? PrescriptionCell {
            cell.prescription = dataSource[indexPath.row]
            cell.accessoryType = .None
            if refillIndexes.contains("\(indexPath.row)") {
                cell.accessoryType = .Checkmark
            }
            return cell
        }
        return UITableViewCell()
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if !refillIndexes.contains("\(indexPath.row)") && refillMode {
            refillIndexes.append("\(indexPath.row)")
            refillButton?.title = "Done"
            tableView.reloadData()
        }
    }
}

