//
//  Prescription.swift
//  WalmartiOS
//
//  Created by Rohit Kumar on 28/10/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import Foundation

class Prescription: NSObject {
    var rxNumber:String?
    var drugName: String?
    var remainingRefill:Int?
    var lastRefillDate:Int64?
    var prescriber:String?
    var price:Int?
    var expiryDate:Int64?
}
