//
//  ViewController.swift
//  WalmartPharma
//
//  Created by Rohit Kumar on 06/11/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var userPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
    
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func loginButtonAction(sender: AnyObject) {
        
        self.userName.resignFirstResponder()
        self.userPassword.resignFirstResponder()
        
        validateInputDetails()

        
    }
    
    
   
    
    func validateInputDetails() {
        
        if (self.userName.text?.characters.count > 0 ) && (self.userPassword.text?.characters.count > 0 ){
            //Safe handling without force unwrap
            if let enteredEmailAddress = self.userName.text {
                
                if WMHelper.isValidEmail(enteredEmailAddress) == true {
                    
                    self.handleLogin()
                    
                }else {
                    let alert = WMHelper.showAlert("Invalid email id", message: "Please enter valid email id")
                    self.presentViewController(alert, animated: true, completion: {
                        
                    })
                }
                
            }
            
            
        }else {
            
            let alert = WMHelper.showAlert("Invalid email id/password", message: "Please enter your email id and password to proceed")
            self.presentViewController(alert, animated: true, completion: {
                
            })
            
        }
        
    }
    
    
    func handleLogin() {
        
            let loginUrl = "\(serverAddress)\(loginUrlEndPoint)emailId=\(self.userName.text!)&pwd=\(self.userPassword.text!)"
            let url:NSURL = NSURL(string: loginUrl)!
            let session = NSURLSession.sharedSession()
            
            let request = NSMutableURLRequest(URL: url)
            request.HTTPMethod = "GET"
            request.cachePolicy = NSURLRequestCachePolicy.ReloadIgnoringCacheData
        
            let task = session.dataTaskWithRequest(request) {
                (
        
                let data, let response, let error) in
                
                guard let responseData:NSData = data, let _:NSURLResponse = response  where error == nil else {
                    let alert = WMHelper.showAlert("Oops", message: "Something went wrong. Please try again")
                    self.presentViewController(alert, animated: true, completion: {
                        
                    })
                    return
                }
            
                do {
                    if let responseJson = try NSJSONSerialization.JSONObjectWithData(responseData, options: []) as? [String:AnyObject] {
                        
                        if let responseStatus = responseJson["status"] as? String where responseStatus == "OK" {
                            
                            //Save customer id
                            WMUserDetails.sharedUserDetails.customerId = responseJson["customerId"] as? Int ?? 0
                            self.proceedToPrescriptionScreen()
                            
                        }else {
                            
                            if let errorResponse = responseJson["error"] as? String {
                                
                                //Display error on main thread
                                dispatch_async(dispatch_get_main_queue(),{
                                    
                                    let alert = WMHelper.showAlert("Oops", message:(errorResponse))
                                    self.presentViewController(alert, animated: true, completion: {
                                        
                                    })
                                    
                                })
                                

                            }
                            
                        }
                        
                    }
                    
                } catch {
                    print("error: \(error)")
                    
                }
                
            }
            
            task.resume()
       
    }
    
    
    
    func proceedToPrescriptionScreen() {
        
        dispatch_async(dispatch_get_main_queue(),{
            
            self.performSegueWithIdentifier("prescriptionScreen", sender: nil)
            
        })
        
    }

    
}



extension ViewController: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(textField: UITextField) {
        
    }
    func textFieldDidEndEditing(textField: UITextField) {
        
    }
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        
        return true;
    }
    func textFieldShouldClear(textField: UITextField) -> Bool {
        return true;
    }
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {
        
        return true;
    }
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
       
        return true;
    }
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder();
        return true;
    }

    
    
}


