//
//  WMConstants.swift
//  WalmartPharma
//
//  Created by Rohit Kumar on 06/11/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import Foundation


let serverAddress = "http://172.28.124.224:8081"

let loginUrlEndPoint = "/customers/authenticate?"

let getPrescriptionsEndPoint = "/prescriptions/"

let getRefillEndPoint = "/refill/"
