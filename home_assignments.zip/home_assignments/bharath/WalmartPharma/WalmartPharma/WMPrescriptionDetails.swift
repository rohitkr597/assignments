//
//  WMPrescriptionDetails.swift
//  WalmartPharma
//
//  Created by Rohit Kumar on 06/11/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import Foundation
import UIKit

class WMPrescriptionDetails: UIViewController {
   
    
    @IBOutlet weak var userPrescriptionTable: UITableView!
    
    private var userPrescrionsList =  [WMUserPrescriptions]()
    private var selectedPrescrionsList =  [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
       self.navigationItem.setHidesBackButton(true, animated:true);
        
        
        let refill = UIBarButtonItem(title: "Refill", style: .Done, target: self, action: #selector(refillTapped))
        navigationItem.rightBarButtonItems = [refill]
        
        
        self.getPrescriptionDetails()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func getPrescriptionDetails() {
        
        let prescriptionUrl = "\(serverAddress)\(getPrescriptionsEndPoint)\(WMUserDetails.sharedUserDetails.customerId)"
        let url:NSURL = NSURL(string: prescriptionUrl)!
        let session = NSURLSession.sharedSession()
        
        let request = NSMutableURLRequest(URL: url)
        request.HTTPMethod = "GET"
        request.cachePolicy = NSURLRequestCachePolicy.ReloadIgnoringCacheData
        
        let task = session.dataTaskWithRequest(request) {
            (
            
            let data, let response, let error) in
            
            guard let responseData:NSData = data, let _:NSURLResponse = response  where error == nil else {
                let alert = WMHelper.showAlert("Oops", message: "Something went wrong. Please try again")
                self.presentViewController(alert, animated: true, completion: {
                    
                })
                return
            }
            
            do {
                if let responseJson = try NSJSONSerialization.JSONObjectWithData(responseData, options: []) as? [String:AnyObject] {
                    
                    if let responseStatus = responseJson["status"] as? String where responseStatus == "OK" {
                        
                        if let prescriptionList = responseJson["prescriptions"] as? [AnyObject] {
                            
                            print("Prescriptions received")
                            self.parseUserPrescriptions(prescriptionList)
                        }
                        
                    }else {
                        
                        if let errorResponse = responseJson["error"] as? String {
                            
                            //Display error on main thread
                            dispatch_async(dispatch_get_main_queue(),{
                                
                                let alert = WMHelper.showAlert("Oops", message:(errorResponse))
                                self.presentViewController(alert, animated: true, completion: {
                                    
                                })
                                
                            })
                            
                            
                        }
                        
                    }
                    
                }
                
            } catch {
                print("error: \(error)")
                
            }
            
        }
        
        task.resume()
        
    }

    
    
    func parseUserPrescriptions(prescriptionList:[AnyObject]) {
    
        
        for prescriptionItem in prescriptionList {
            
            let userPrescriptionItem = WMUserPrescriptions()
            userPrescriptionItem.rxNumber               =   prescriptionItem["RxNumber"] as? String ?? ""
            userPrescriptionItem.drugName               =   prescriptionItem["drugName"] as? String ?? ""
            userPrescriptionItem.noOfRemainingRefill    =   prescriptionItem["noOfRemainingRefill"] as? Int ?? 0
            userPrescriptionItem.lastRefillDate         =   prescriptionItem["lastRefillDate"] as? String ?? ""
            userPrescriptionItem.prescriberName         =   prescriptionItem["prescriberName"] as? String ?? ""
            userPrescriptionItem.price                  =   prescriptionItem["price"] as? Int ?? 0
            userPrescriptionItem.expirationDate         =   prescriptionItem["expirationDate"] as? String ?? ""
            
            self.userPrescrionsList.append(userPrescriptionItem)
            
        }
     
        //Update table on main thread
        dispatch_async(dispatch_get_main_queue(),{
            
            self.userPrescriptionTable.reloadData()
        })
        
    }
    
    func refillTapped() {
    
        if self.selectedPrescrionsList.count > 0 {
            
            let rxNumberList = self.selectedPrescrionsList.joinWithSeparator(",")
            let refillUrl = "\(serverAddress)\(getRefillEndPoint)\(WMUserDetails.sharedUserDetails.customerId)?rxNumber=\(rxNumberList)"
            let url:NSURL = NSURL(string: refillUrl)!
            let session = NSURLSession.sharedSession()
            
            let request = NSMutableURLRequest(URL: url)
            request.HTTPMethod = "GET"
            request.cachePolicy = NSURLRequestCachePolicy.ReloadIgnoringCacheData
            
            let task = session.dataTaskWithRequest(request) {
                (
                
                let data, let response, let error) in
                
                guard let responseData:NSData = data, let _:NSURLResponse = response  where error == nil else {
                    let alert = WMHelper.showAlert("Oops", message: "Something went wrong. Please try again")
                    self.presentViewController(alert, animated: true, completion: {
                        
                    })
                    return
                }
                
                do {
                    if let responseJson = try NSJSONSerialization.JSONObjectWithData(responseData, options: []) as? [String:AnyObject] {
                        
                        if let responseStatus = responseJson["status"] as? String where responseStatus == "OK" {
                            
                            dispatch_async(dispatch_get_main_queue(),{
                                
                                let descriptionMesg = responseJson["description"] as! String
                                let alert = WMHelper.showAlert("", message:descriptionMesg)
                                self.presentViewController(alert, animated: true, completion: {
                                    
                                })
                                
                            })
                            
                        }else {
                            
                            if let errorResponse = responseJson["error"] as? String {
                                
                                //Display error on main thread
                                dispatch_async(dispatch_get_main_queue(),{
                                    
                                    let alert = WMHelper.showAlert("Oops", message:(errorResponse))
                                    self.presentViewController(alert, animated: true, completion: {
                                        
                                    })
                                    
                                })
                                
                                
                            }
                            
                        }
                        
                    }
                    
                } catch {
                    print("error: \(error)")
                    
                }
                
            }
            
            task.resume()
        }
        else {
            
            
        }
        

        
    }
    
}


extension WMPrescriptionDetails:  UITableViewDelegate {
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.userPrescrionsList.count
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }
    
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let vw = UIView()
        vw.backgroundColor = UIColor.redColor()
        
        return vw
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        return 99.0;
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 1.0
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
      
        let cell = self.userPrescriptionTable.dequeueReusableCellWithIdentifier("prescriptionCell")! as! WMPrescriptionCell
        
        if let userPrescriptionItem = self.userPrescrionsList[indexPath.row] as? WMUserPrescriptions {
            
            cell.drugName.text =    userPrescriptionItem.drugName
            cell.price.text = String(format: "%d",userPrescriptionItem.price)
            cell.noOfRemainingRefill.text = String(format: "%d",userPrescriptionItem.noOfRemainingRefill)
            cell.prescriberName.text =    userPrescriptionItem.prescriberName
            cell.indexPathOfCell = indexPath.row
            cell.delegate = self
        }
        
        
        return cell
    }
    
    
}




extension WMPrescriptionDetails : SelectionDelegate {
    
    func selectedPrescriptionItem(rowIndex: Int, selectedState: Bool) {
        
        if let userPrescriptionItem = self.userPrescrionsList[rowIndex] as? WMUserPrescriptions {
            
            if selectedState == true {
               
                self.selectedPrescrionsList.append(userPrescriptionItem.rxNumber)
                
            }else {
                
                //Remove  unselected prescription
                self.selectedPrescrionsList = self.selectedPrescrionsList.filter( { $0 != userPrescriptionItem.rxNumber} )
                
            }
            
        }
        
    }
    
}