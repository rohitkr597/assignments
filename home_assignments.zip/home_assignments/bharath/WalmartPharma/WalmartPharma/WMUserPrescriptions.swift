//
//  WMUserPrescriptions.swift
//  WalmartPharma
//
//  Created by Rohit Kumar on 06/11/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import Foundation


class WMUserPrescriptions {
    
    
    var rxNumber = ""
    var drugName = ""
    var noOfRemainingRefill = 0
    var lastRefillDate = ""
    var prescriberName = ""
    var price = 0
    var expirationDate = ""
    
    init() {
        
    }
    
}