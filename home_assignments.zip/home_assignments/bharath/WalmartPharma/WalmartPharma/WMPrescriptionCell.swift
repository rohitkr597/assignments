//
//  WMPrescriptionCell.swift
//  WalmartPharma
//
//  Created by Rohit Kumar on 06/11/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

import Foundation
import UIKit

protocol SelectionDelegate {
    
    func selectedPrescriptionItem(rowIndex: Int, selectedState: Bool)
}

class WMPrescriptionCell: UITableViewCell {

    var delegate: SelectionDelegate?
    
    var indexPathOfCell: Int = 0
    
    @IBOutlet weak var selectPrescriptionButton: UIButton!
    
    @IBOutlet weak var price: UILabel!
    
    @IBOutlet weak var drugName: UILabel!
    
    @IBOutlet weak var prescriberName: UILabel!
    
    @IBOutlet weak var noOfRemainingRefill: UILabel!
    
    var prescriptionSelected = false
    
    @IBAction func selectPrescriptionAction(sender: AnyObject) {
        
        if prescriptionSelected == true {
            prescriptionSelected = false
            selectPrescriptionButton.setImage(UIImage(named: "Untick"), forState: .Normal)
            
        }else {
            
            prescriptionSelected = true
            selectPrescriptionButton.setImage(UIImage(named: "Tick"), forState: .Normal)
            
        }
        
        delegate?.selectedPrescriptionItem(indexPathOfCell, selectedState: prescriptionSelected)
        
    }
}
