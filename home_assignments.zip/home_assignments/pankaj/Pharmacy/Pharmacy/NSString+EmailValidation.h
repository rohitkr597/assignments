//
//  NSString+EmailValidation.h
//  Pharmacy
//
//  Created by Rohit Kumar on 08/11/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (EmailValidation)

-(BOOL)isValidEmail;

@end
