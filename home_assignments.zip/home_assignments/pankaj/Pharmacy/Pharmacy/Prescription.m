//
//  Pharmacy.m
//  Pharmacy
//
//  Created by Rohit Kumar on 07/11/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

#import "Prescription.h"

@implementation Prescription

@end
