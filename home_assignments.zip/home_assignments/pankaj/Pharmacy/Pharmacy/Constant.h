//
//  Constant.h
//  Pharmacy
//
//  Created by Rohit Kumar on 08/11/16.
//  Copyright © 2016 Walmart. All rights reserved.
//

#ifndef Constant_h
#define Constant_h

#define baseURL @""


#endif /* Constant_h */
